//40
// function a(text) {
//   if (text === "") {
//     return 0;
//   } else {
//     return 1 + a(text.slice(1));
//   }
// }

// let matn = prompt("");
// let natija = a(matn);
// console.log("Matnda", natija, "belgi bor.");

//41
// function bolinadimi(son1, son2) {
//   if (son1 % son2 === 0) {
//     return true;
//   } else {
//     return false;
//   }
// }

// let son1 = prompt("");
// let son2 = prompt("");
// let natija = bolinadimi(son1, son2);
// console.log(natija);

//42
// function raqamTuri(raqamString) {
//   if (/^\d+$/.test(raqamString)) {
//     return Number(raqamString);
//   } else {
//     return null;
//   }
// }

// let raqamString = "123";
// let raqam = raqamTuri(raqamString);
// console.log(raqam);

//43
// function tortburchakYuzi(tomon1, tomon2) {
//   if (tomon1 <= 0 || tomon2 <= 0) {
//     return -1;
//   } else {
//     let yuz = tomon1 * tomon2;
//     return yuz;
//   }
// }

// let tomon1 = prompt("");
// let tomon2 = prompt("");
// let yuz = tortburchakYuzi(tomon1, tomon2);
// if (yuz !== -1) {
//   console.log("To'rtburchakning yuzi:", yuz);
// } else {
//   console.log("Tomonlar xato kiritilgan.");
// }

//44
// function ismFamiliyaFormat(ism, familiya) {
//   return ism + ", " + familiya;
// }
// var ism = prompt("");
// var familiya = prompt("");
// var natija = ismFamiliyaFormat(familiya, ism);
// console.log(natija);

//45
// function bug(yomonmi) {
//   return yomonmi ? "sad days" : "it's a good day";
// }

// console.log(bug(true));
// console.log(bug(false));

//46
// function tushiribQoldir(massiv, n) {
//   let tushirilganNatija = "";

//   if (n <= massiv.length) {
//     tushirilganNatija =
//       massiv.slice(0, n).join("") + "22EDABIT" + massiv.slice(n).join("");
//   } else {
//     tushirilganNatija = massiv.join("");
//   }

//   return tushirilganNatija;
// }

// let massiv = ["a", "b", "c", "d"];
// let n = 2;
// let natija = tushiribQoldir(massiv, n);
// console.log(natija);

//47
// function ovozQollashlar(ovoziBormi, ovoziYoqmi) {

//   let qollabQuvvatlananlar = 0;

//   let bermaganlar = 0;

//   for (let i = 0; i < ovoziBormi.length; i++) {
//     if (ovoziBormi[i]) {
//       qollabQuvvatlananlar++;
//     } else {
//       bermaganlar++;
//     }
//   }

//   return {
//     qollabQuvvatlananlar: qollabQuvvatlananlar,
//     bermaganlar: bermaganlar,
//   };
// }

// let ovoziBormi = [true, true, false, true, false];
// let ovoziYoqmi = [false, true, false, false, true];
// let natija = ovozQollashlar(ovoziBormi, ovoziYoqmi);
// console.log(natija);

//48
// function negativniQaytar(son) {
//   return -son;
// }

// var son = prompt("");
// var natija = negativniQaytar(son);
// console.log(natija);

//49
// function almashtirish(massiv) {
//   let yangiMassiv = [];
//   for (let i = massiv.length - 1; i >= 0; i--) {
//     yangiMassiv.push(massiv[i]);
//   }

//   return yangiMassiv;
// }

// let aslMassiv = [1, 2, 3, 4, 5];
// let yangiMassiv = almashtirish(aslMassiv);
// console.log("Yangi massiv:", yangiMassiv);

//50
function kinoteatrgaBorish(yosh, birgaBolganmi) {
  return yosh >= 15 && birgaBolganmi;
}

let yosh1 = 10;
let birgaBolganmi1 = true;
console.log(kinoteatrgaBorish(yosh1, birgaBolganmi1));

let yosh2 = 16;
let birgaBolganmi2 = true;
console.log(kinoteatrgaBorish(yosh2, birgaBolganmi2));
